function [ vp, l] = P_iteree( A )
%M�thode 1
%Retourne le vecteur propre max et la valeur propre associ�e
%   A : Matrice a tester
%   l : Valeur propre
%   vp: Vecteur propre

X=diag(rand(max(size(A))));
Ya=X;
Y=X;
l=4;
la=0;
while abs(l-la)>=1E-3
    la=l;
    Ya=Y;
    
    X=Ya/norm(Ya);
    Y=A*X;

    vp=Y/norm(Y);
    Z=A*vp;
    [M,k]=max(Z);
    
    l=(Z(k))/(vp(k));
end

% disp(l) ;
% disp(vp);

end