function [ X, l1] = Deflation( A )
%Suppression du vecteur propre max d'une matrice A dont on veut supprimer la valeur max

[v,l1]=P_iteree(A);
[u,l2]=P_iteree(A');

if abs(l1-l2)<=1E-1
    X=A-l1*((v*(u'))/((u')*v));
else
    [X, l1] = Deflation(A);
end

% Autre code plus pratique si execution de ce programme seul
% function [X,l] = Deflation(A,nb_Deflations)
% %
% %   A : Matrice a tester
% %   nb_Deflations : rang de la vp qu'on souhaite extraire a chaque execution
% %   du code ; REMARQUE : SI ON DECOMMENTE LES DISP, LE CODE AFFICHERA
% %   TOUTES LES VP PRECEDENT LA VP QU'ON VEUT EXTRAIRE
% 
% [u,l1] = P_iteree(A') ; %Calcul du vecteur propre ligne et de sa valeur propre dominante associée
% [v,l2] = P_iteree(A) ; %Calcul du vecteur propre colonne et de sa valeur propre dominante associée
% 
% % disp(l2) ;
% % disp(v) ; 
% 
% l = l2 ; 
% X = v ;
% 
% for i = 2 : nb_Deflations
%     A = A - l1 * (v*u') / (u'*v) ; 
%     [u,l1] = P_iteree(A') ;
%     [v,l2] = P_iteree(A) ;
%     l = l2 ; 
%     X = v ;
%     % disp(l) ;
%     % disp(X) ; 
% end
